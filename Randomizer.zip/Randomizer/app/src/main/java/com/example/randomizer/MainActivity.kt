package com.example.randomizer

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import kotlin.random.Random
import java.util.*
abstract class Random

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
      fun buttonPressed(view: View){
          //random generator
          val myRandomInt = Random.nextInt(100 )
          //inputting that random value in a string and printing it in the textView
          val textView: TextView = findViewById(R.id.textView)

          textView.text = "$myRandomInt"

      }      }